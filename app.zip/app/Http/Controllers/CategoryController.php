<?php

namespace App\Http\Controllers;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Requests\AddCateRequest;
class CategoryController extends Controller
{   
    public function index()
    {
       
    }
    public function create()
    {
        //
        $cates =  Category::all();
        return view('admin.category.cate-add',compact('cates'));
    }


    public function getCateList()
    {
        $cates = Category::all();
       
        return view('admin.category.cate-list',compact('cates'));
       
    } 


    public function getCateAdd()
    {
        $cates =  Category::all();
        return view('admin.category.cate-add',compact('cates'));

    } 
    public function getCateDelete()
    {
        DB::delete('delete from type_products where id = ?', [$id]);
        // $id->delete();
        return redirect('admin/danhsach')->with('thongbao','Xóa xe thành công!');

    } 


    public function postCateAdd(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required',
            'description' => 'required',
   
        ], [
            'name.required' => 'Bạn chưa nhập tên !',
            'description.required' => 'Bạn chưa nhập giá !', 
           
        ]);
       
        $getimg = '';
        if($request->hasFile('image')){
            //Hàm kiểm tra dữ liệu
            $this->validate($request, 
                [
                    //Kiểm tra đúng file đuôi .jpg,.jpeg,.png.gif và dung lượng không quá 2M
                    'image' => 'mimes:jpg,jpeg,png,gif|max:2048',
                ],			
                [
                    //Tùy chỉnh hiển thị thông báo không thõa điều kiện
                    'image.mimes' => 'Chỉ chấp nhận hình thẻ với đuôi .jpg .jpeg .png .gif',
                    'image.max' => 'Hình thẻ giới hạn dung lượng không quá 2M',
                ]
            );
              
            //Lưu hình ảnh vào thư mục public/upload/img
            $image = $request->file('image');
            $getimg = time().'_'.$image->getClientOriginalName();
            $destinationPath = public_path('assets');
            $image->move($destinationPath, $getimg);
        }
        // $img = $request->file('img');
        // $getimg = time().'_'.$img->getClientOriginalName();
        // $destinationPath = public_path('assets');
        // $img->move($destinationPath, $getimg);
        //
        $cate = new Category;
        $cate->name = $request->name; 
        $cate->description = $request->description;
      
        $cate->image = $getimg;
      
        
       
        $cate->save();
        return redirect('admin/cate-list')->with('thongbao','Thêm xe thành công!');
       
    }
    

    



    public function getCateEdit(string $id)
    {
        //
        $categorys = Category::find($id); 
      
        return view('admin.category.cate-edit', compact( 'categorys'));
    }
    public function postCateEdit(Request $request, string $id)
    {
        $validated = $request->validate([
            'name' => 'required',
          
           
            'description' => 'required',
            'image' => 'required',
            
            
        ], [
            'name.required' => 'Bạn chưa nhập tên !',
           
            'desciption.required' => 'Bạn chưa nhập mô tả !',

           
        ]);
        $getimg = '';
        if($request->hasFile('image')){
            //Hàm kiểm tra dữ liệu
            $this->validate($request, 
                [
                    //Kiểm tra đúng file đuôi .jpg,.jpeg,.png.gif và dung lượng không quá 2M
                    'image' => 'mimes:jpg,jpeg,png,gif|max:2048',
                ],			
                [
                    //Tùy chỉnh hiển thị thông báo không thõa điều kiện
                    'image.mimes' => 'Chỉ chấp nhận hình thẻ với đuôi .jpg .jpeg .png .gif',
                    'image.max' => 'Hình thẻ giới hạn dung lượng không quá 2M',
                ]
            );
              
            //Lưu hình ảnh vào thư mục public/upload/img
            $image = $request->file('image');
            $getimg = time().'_'.$image->getClientOriginalName();
            $destinationPath = public_path('assets');
            $image->move($destinationPath, $getimg);
        }
        // $img = $request->file('img');
        // $getimg = time().'_'.$img->getClientOriginalName();
        // $destinationPath = public_path('assets');
        // $img->move($destinationPath, $getimg);
        //
     
        $name = $request->name; 
       
        $description = $request->description;
      
        $image = $getimg;
       
        DB::table('type_products')->where('id', $id)->update([
            'name' =>   $name ,
           
            'description' =>  $description,
            
            'image'=> $image,
            
        ]);
        return redirect('admin/danhsach')->with('thongbao','Cập nhật food thành công!');
    }
    
    
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, string $id)
    {
        $validated = $request->validate([
            'name' => 'required',
          
           
            'detail' => 'required',
            'img' => 'required',
            
            
        ], [
            'name.required' => 'Bạn chưa nhập tên !',
           
            'detail.required' => 'Bạn chưa nhập mô tả !',

           
        ]);
        $getimg = '';
        if($request->hasFile('image')){
            //Hàm kiểm tra dữ liệu
            $this->validate($request, 
                [
                    //Kiểm tra đúng file đuôi .jpg,.jpeg,.png.gif và dung lượng không quá 2M
                    'img' => 'mimes:jpg,jpeg,png,gif|max:2048',
                ],			
                [
                    //Tùy chỉnh hiển thị thông báo không thõa điều kiện
                    'img.mimes' => 'Chỉ chấp nhận hình thẻ với đuôi .jpg .jpeg .png .gif',
                    'img.max' => 'Hình thẻ giới hạn dung lượng không quá 2M',
                ]
            );
              
            //Lưu hình ảnh vào thư mục public/upload/img
            $img = $request->file('img');
            $getimg = time().'_'.$image->getClientOriginalName();
            $destinationPath = public_path('assets');
            $image->move($destinationPath, $getimg);
        }
        // $img = $request->file('img');
        // $getimg = time().'_'.$img->getClientOriginalName();
        // $destinationPath = public_path('assets');
        // $img->move($destinationPath, $getimg);
        //
     
        $name = $request->name; 
       
        $detail = $request->detail;
      
        $image = $getimg;
       
        DB::table('type_products')->where('id', $id)->update([
            'name' =>   $name ,
           
            'detail' =>  $detail,
            
            'img'=> $img,
            
        ]);
        return redirect('admin/danhsach')->with('thongbao','Cập nhật food thành công!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy( string $id)
    {
        //
        DB::delete('delete from type_products where id = ?', [$id]);
        // $id->delete();
        return redirect('admin/danhsach')->with('thongbao','Xóa xe thành công!');
    }
}
