@extends('admin.master')
@if (session('massage'))
		<div class ="alert alert-massage">
		 {{ session('massage')}}</div>
		 @endif
	@section('content')

                <!-- Begin Page Content -->
                <div class="container-fluid">

                   

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Danh Mục Sản Phẩm</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                             
                                <thead>

                                        <tr>
                                            <th>Name</th>
                                            <th>Description</th>
                                            <th>Image</th>
                                            <th>Edit</th>
                                            <th>Add</th>
                                            <th>Delete</th>
                                            
                                        </tr>
                                    </thead>
                                   
                                    <tbody>
                                    @foreach($cates as $cate)
                                    <tr>
                                            <td>{{ $cate['name']; }}</td>
                                            <td>{{ $cate['description']; }}</td>
                                            <td><img src="/source/image/product/{{ $cate['image']; }}"height="50em" margin="auto" alt=""></td>
                                            <td><a href="{{route('admin.getCateEdit',$cate->id)}}"><button class="button button3">Sửa</button></a></td>
                                            <td><a href="{{route('admin.getCateAdd')}}"><button class="button button3">Thêm</button></a></td>
                                            <td><form action="{{route('admin.getCateDelete',$cate->id)}}" method="post">
                     
                     @csrf
                     @method('DELETE')
                     <input type="submit" class="button button2" value="Xóa">
                   </form></td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                   
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

           
           
          
        

   

            @endsection	

@section('js')
@endsection	