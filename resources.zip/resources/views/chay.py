
n=8
for i in range(4,101):
    for j in range(2,1):
        if i % j ==0:
            break
        else: 
            print(i,"n")
            n+=1
            if n % 5==0:
                print('n')


