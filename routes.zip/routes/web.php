<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\CategoryController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('index',[PageController::class,'index']
);
Route::get('chitiet',[PageController::class,'show']
);
Route::resource('products',PageController::class);
Route::get('product',[PageController::class,'product']
);
Route::get('contact',[PageController::class,'contact']
);
Route::get('product_type',[PageController::class,'product_type']
);
Route::get('checkout',[PageController::class,'getCheckout']
)->name('banhang.getdathang');
Route::post('checkout',[PageController::class,'postCheckout']
)->name('banhang.postdathang');
Route::get('shopping_cart',[PageController::class,'shopping_cart']
);
Route::get('add-to-cart/{id}',[PageController::class,'addToCart'])->name('banhang.addToCart');
Route::get('del-cart/{id}',[PageController::class,'delCartItem'])->name('banhang.xoagiohang');
//đăng ký của khách hàng
Route::get('dangky',[PageController::class,'getSignin'])->name('getsignin');
Route::post('dangky',[PageController::class,'postSignin'])->name('postsignin');


Route::get('/admin/dangnhap',[UserController::class,'getLogin'])->name('admin.getLogin');
Route::post('/admin/dangnhap',[UserController::class,'postLogin'])->name('admin.postLogin');
Route::get('/admin/dangxuat',[UserController::class,'getLogout']);

Route::get('/dangnhap',[PageController::class,'getLogin'])->name('getLogin');
Route::post('dangnhap',[PageController::class,'postLogin'])->name('postLogin');
Route::get('/dangxuat',[PageController::class,'getLogout']);


Route::group(['prefix'=>'admin','middleware'=>'adminLogin'],function(){  
    Route::group(['prefix'=>'category'],function(){
         // admin/category/danhsach
         Route::get('danhsach',[CategoryController::class,'getCateList'])->name('admin.getCateList');
         Route::post('danhsach',[CategoryController::class,'postCateList'])->name('admin.postCateList');
         Route::get('them',[CategoryController::class,'getCateAdd'])->name('admin.getCateAdd');
         Route::post('them',[CategoryController::class,'postCateAdd'])->name('admin.postCateAdd');
         Route::get('xoa/{id}',[CategoryController::class,'getCateDelete'])->name('admin.getCateDelete');
         Route::get('sua/{id}',[CategoryController::class,'getCateEdit'])->name('admin.getCateEdit');
         Route::post('sua/{id}',[CategoryController::class,'postCateEdit'])->name('admin.postCateEdit');
       
     });
//viết tiếp các route khác cho crud products, users,.... thì viết tiếp

});
