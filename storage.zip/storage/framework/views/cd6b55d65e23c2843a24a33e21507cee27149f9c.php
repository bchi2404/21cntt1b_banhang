<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Laravel </title>
	<link href='http://fonts.googleapis.com/css?family=Dosis:300,400' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="/source/assets/dest/css/font-awesome.min.css">
	<link rel="stylesheet" href="/source/assets/dest/vendors/colorbox/example3/colorbox.css">
	<link rel="stylesheet" href="/source/assets/dest/rs-plugin/css/settings.css">
	<link rel="stylesheet" href="/source/assets/dest/rs-plugin/css/responsive.css">
	<link rel="stylesheet" title="style" href="/source/assets/dest/css/style.css">
	<link rel="stylesheet" href="/source/assets/dest/css/animate.css">
	<link rel="stylesheet" title="style" href="/source/assets/dest/css/huong-style.css">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>

	<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent('content'); ?>
	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


	<!-- include js files -->
	<script src="/source/assets/dest/js/jquery.js"></script>
	<script src="/source/assets/dest/vendors/jqueryui/jquery-ui-1.10.4.custom.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
	<script src="/source/assets/dest/vendors/bxslider/jquery.bxslider.min.js"></script>
	<script src="/source/assets/dest/vendors/colorbox/jquery.colorbox-min.js"></script>
	<script src="/source/assets/dest/vendors/animo/Animo.js"></script>
	<script src="/source/assets/dest/vendors/dug/dug.js"></script>
	<script src="/source/assets/dest/js/scripts.min.js"></script>
	<script src="/source/assets/dest/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
	<script src="/source/assets/dest/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
	<script src="/source/assets/dest/js/waypoints.min.js"></script>
	<script src="/source/assets/dest/js/wow.min.js"></script>
<?php echo $__env->yieldContent('js'); ?>
	
</body>
</html>
<?php /**PATH C:\xampp\htdocs\21cntt1b_banhang\resources\views/layouts/master.blade.php ENDPATH**/ ?>