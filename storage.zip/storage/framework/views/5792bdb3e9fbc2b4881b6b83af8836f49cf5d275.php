
<?php if(session('massage')): ?>
		<div class ="alert alert-massage">
		 <?php echo e(session('massage')); ?></div>
		 <?php endif; ?>
	<?php $__env->startSection('content'); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                   

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Danh Mục Sản Phẩm</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                             
                                <thead>

                                        <tr>
                                            <th>Name</th>
                                            <th>Description</th>
                                            <th>Image</th>
                                            <th>Edit</th>
                                            <th>Add</th>
                                            <th>Delete</th>
                                            
                                        </tr>
                                    </thead>
                                   
                                    <tbody>
                                    <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                            <td><?php echo e($cate['name']); ?></td>
                                            <td><?php echo e($cate['description']); ?></td>
                                            <td><img src="/source/image/product/<?php echo e($cate['image']); ?>"height="50em" margin="auto" alt=""></td>
                                            <td><a href="<?php echo e(route('admin.getCateEdit',$cate->id)); ?>"><button class="button button3">Sửa</button></a></td>
                                            <td><a href="<?php echo e(route('admin.getCateAdd')); ?>"><button class="button button3">Thêm</button></a></td>
                                            <td><form action="<?php echo e(route('admin.getCateDelete',$cate->id)); ?>" method="post">
                     
                     <?php echo csrf_field(); ?>
                     <?php echo method_field('DELETE'); ?>
                     <input type="submit" class="button button2" value="Xóa">
                   </form></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                   
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

           
           
          
        

   

            <?php $__env->stopSection(); ?>	

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\21cntt1b_banhang\resources\views/admin/category/cate-list.blade.php ENDPATH**/ ?>