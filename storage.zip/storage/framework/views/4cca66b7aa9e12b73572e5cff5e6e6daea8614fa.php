
	
	<?php $__env->startSection('content'); ?>
	<div class="rev-slider">
	<div class="fullwidthbanner-container">
					<div class="fullwidthbanner">
						<div class="bannercontainer" >
					    <div class="banner" >
                        <ul>
									<!-- THE FIRST SLIDE -->
									<?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li data-transition="boxfade"
									 
										data-slotamount="20" 
										class="active-revslide" 
										style="width: 100%; height: 100%; overflow: hidden; z-index: 18; visibility: hidden; opacity: 0;">
						            <div class="slotholder" 
									style="width:100%;height:100%;" 
									data-duration="undefined" 
									data-zoomstart="undefined" 
									data-zoomend="undefined" 
									data-rotationstart="undefined" 
									data-rotationend="undefined" 
									data-ease="undefined" 
									data-bgpositionend="undefined" 
									data-bgposition="undefined" 
									data-kenburns="undefined" 
									data-easeme="undefined" 
									data-bgfit="undefined" 
									data-bgfitend="undefined" 
									data-owidth="undefined" 
									data-oheight="undefined">
													<div class="tp-bgimg defaultimg" 
													data-lazyload="undefined" 
													data-bgfit="cover" 
													data-bgposition="center center" 
													data-bgrepeat="no-repeat" 
													data-lazydone="undefined" 
													src="/source/image/slide/<?php echo e($slide['image']); ?>" 
													data-src="/source/image/slide/<?php echo e($slide['image']); ?>" 
													style="background-color: rgba(0, 0, 0, 0); background-repeat: no-repeat; background-image: url('/source/image/slide/<?php echo e($slide['image']); ?>'); background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; visibility: inherit;">
													</div>
												</div>
						        </li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
</div>
						</div>

						<div class="tp-bannertimer"></div>
					</div>
				</div>
				<!--slider-->
	</div>
	<div class="container" >
		<div id="content" class="space-top-none">
			<div class="main-content">
				<div class="space60">&nbsp;</div>
				<div class="row">
					<div class="col-sm-12">
						<div class="beta-products-list">
							<h4><b>Sản Phẩm Khuyến Mãi</h4>
							<div class="beta-products-details">
								<p class="pull-left"><?php echo e(isset($products)?count($products):0); ?> Sản Phẩm</p>
								<div class="clearfix"></div>
							</div>
							<?php 
							$stt = 0;
							?>
							<div class="row">
							<?php if(isset($products)): ?>
							<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php 
							$stt++;
							?>
								<div class="col-sm-3" >
									<div class="single-item">
										<div class="single-item-header">
											<a href="product"><img src="/source/image/product/<?php echo e($products['image']); ?>"height="200em" margin="auto" alt=""></a>
										</div>
										<div class="single-item-body">
										<b>	<p class="single-item-title"><?php echo e($products['name']); ?></p></b>
											<p class="single-item-price">
												<span class="flash-del"><?php echo e($products['unit_price']); ?></span>
												<span class="flash-sale"><?php echo e($products['promotion_price']); ?></span>
											</p>
										</div>
										<div class="single-item-caption">
											<a class="add-to-cart pull-left" href="<?php echo e(route('banhang.addToCart',$products->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
											<a href="<?php echo e(route('products.show' , $products->id)); ?>" class="container__detail-link">Chi tiết</a>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
								
							</div>
						</div> <!-- .beta-products-list -->
				
						<div class="space50">&nbsp;</div>

						<div class="beta-products-list">
						<h4><b>Sản Phẩm Đề Nghị</h4>
							<div class="beta-products-details">
								<p class="pull-left"><?php echo e(isset($pro)?count($pro):0); ?> Sản Phẩm</p>
								<div class="clearfix"></div>
							</div>
							<?php 
							$stt = 0;
							?>
							<div class="row">
							<?php if(isset($products)): ?>
							<?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php 
							$stt++;
							?>
								<div class="col-sm-3" >
									<div class="single-item">
										<div class="single-item-header">
											<a href="product"><img src="/source/image/product/<?php echo e($pro['image']); ?>"height="200em" margin="auto" alt=""></a>
										</div>
										<div class="single-item-body">
										<b>	<p class="single-item-title"><?php echo e($pro['name']); ?></p></b>
											<p class="single-item-price">
												<span class="flash-del"><?php echo e($pro['unit_price']); ?></span>
												<span class="flash-sale"><?php echo e($pro['promotion_price']); ?></span>
											</p>
										</div>
										<div class="single-item-caption">
											<a class="add-to-cart pull-left" href="<?php echo e(route('banhang.addToCart',$pro->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
											<a href="<?php echo e(route('products.show' , $pro->id)); ?>" class="container__detail-link">Chi tiết</a>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
								
							</div>
						</div> <!-- .beta-products-list -->
						<div class="space50">&nbsp;</div>

					<b>	<h4><b>Tất Cả Sản Phẩm </h4>
							<div class="beta-products-details">
								<p class="pull-left"><?php echo e(isset($products)?count($product):0); ?> Sản Phẩm</p>
								<div class="clearfix"></div>
							</div>
							<?php 
							$stt = 0;
							?>
							<div class="row">
							<?php if(isset($products)): ?>
							<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php 
							$stt++;
							?>
								<div class="col-sm-3" >
									<div class="single-item">
										<div class="single-item-header">
											<a href="product"><img src="/source/image/product/<?php echo e($product['image']); ?>"height="200em" margin="auto" alt=""></a>
										</div>
										<div class="single-item-body">
										<b>	<p class="single-item-title"><?php echo e($product['name']); ?></p></b>
											<p class="single-item-price">
												<span class="flash-del"><?php echo e($product['unit_price']); ?></span>
												<span class="flash-sale"><?php echo e($product['promotion_price']); ?></span>
											</p>
										</div>
										<div class="single-item-caption">
											<a class="add-to-cart pull-left" href="<?php echo e(route('banhang.addToCart',$product->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
											<a href="<?php echo e(route('products.show' , $product->id)); ?>" class="container__detail-link">Chi tiết</a>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								
								
							</div>
						</div> <!-- .beta-products-list -->
				



					</div>
				</div> <!-- end section with sidebar and main content -->


			</div> <!-- .main-content -->
		</div> <!-- #content -->
	</div> <!-- .container -->
	<?php $__env->stopSection(); ?>	

	<?php $__env->startSection('js'); ?>
	<!--customjs-->
	<script src="source/assets/dest/js/custom2.js"></script>
	<script>
	$(document).ready(function($) {    
		$(window).scroll(function(){
			if($(this).scrollTop()>150){
			$(".header-bottom").addClass('fixNav')
			}else{
				$(".header-bottom").removeClass('fixNav')
			}}
		)
	})
	
	</script>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\21cntt1b_banhang\resources\views/index.blade.php ENDPATH**/ ?>